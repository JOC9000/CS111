//NAME: Jorge Contreras, Nevin Liang
//EMAIL: jorgec9000@g.ucla.edu, nliang868@g.ucla.edu
//ID: 205379811, 705575353

#include <linux/types.h>
#include "ext2_fs.h"
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>


void exit_handler(int exit_num, char error_info[]) {
  fprintf(stderr, "%s: %s\n", error_info, strerror(errno));
	exit(exit_num);
}


void gm_get(time_t time, char *result) {
  struct tm time_capt = *gmtime(&time);
  int year = time_capt.tm_year;
  while(year >= 100)
    year = year - 100;
      
  snprintf(result, 100, "%02d/%02d/%02d %02d:%02d:%02d", time_capt.tm_mon + 1,
	   time_capt.tm_mday, year, time_capt.tm_hour, time_capt.tm_min, time_capt.tm_sec);
}


void indir(int fd, int block, int block_size, int parent_node, int start_index, int lvl) {
  unsigned int ref_block;
  int num_ptd_blocks = block_size / sizeof(ref_block);
  int i; 
  
  for(i = 0; i < num_ptd_blocks; i = i + 1) {
    pread(fd, &ref_block, sizeof(ref_block), 1024 + (block-1)*block_size +
	  (i)*sizeof(ref_block));

    if(ref_block != 0) {
      printf("INDIRECT,%d,%d,%d,%d,%d\n", parent_node, lvl, start_index+i, block, ref_block);
      if(lvl > 1)
	indir(fd, ref_block, block_size, parent_node, start_index+i, lvl-1);
    }
  }
}


int main(int argc, char* argv[]) {

  if (argc < 2)
    exit_handler(1, "No argument provided. Please provide image location. Use: ./lab3a /file/loc");
  
  int fd;
  struct ext2_super_block super;
  char* img_path = argv[1];

  if(access(img_path, F_OK) < 0)
    exit_handler(1, "Given file does not exist! ");

  fd = open(img_path, O_RDONLY);

  if (fd < 0)
    exit_handler(2, "Error opening image");

  pread(fd, &super, sizeof(super), 1024);

  if (super.s_magic != EXT2_SUPER_MAGIC)
    exit_handler(1, "Wrong file system provided");

  int block_size = 1024 << super.s_log_block_size;
  int inode_size = super.s_inode_size;
  int num_blocks = super.s_blocks_count;
  int num_inodes = super.s_inodes_count;
	
  printf("SUPERBLOCK,%d,%d,%d,%d,%d,%d,%d\n", num_blocks, num_inodes, 
	 block_size, inode_size, super.s_blocks_per_group, super.s_inodes_per_group, 
	 super.s_first_ino);



  int num_groups = 1 + (super.s_blocks_count - 1)/super.s_blocks_per_group;
  struct ext2_group_desc group_desc[num_groups];
  int i, iter;
	
  for(i = 0; i < num_groups; i = i + 1) {
    pread(fd, &group_desc[i], sizeof(group_desc[0]), 1024 + ((i+1)*block_size));
    
    printf("GROUP,%d,%d,%d,%d,%d,%d,%d,%d\n", i, num_blocks/num_groups,
	   num_inodes/num_groups, group_desc[i].bg_free_blocks_count,
	   group_desc[i].bg_free_inodes_count, group_desc[i].bg_block_bitmap,
	   group_desc[i].bg_inode_bitmap, group_desc[i].bg_inode_table);
  }

  char bitmap[block_size];
  pread(fd, bitmap, block_size, 1024 + (group_desc[0].bg_block_bitmap - 1)*block_size);

  for(i = 1; i < (num_blocks/num_groups)+1; i = i + 1) {
    int index = (i-1)/8;
    int offset = (i -1) % 8;
    if((bitmap[index] & (1 << offset)) == 0)
      printf("BFREE,%d\n", i);
  }

  pread(fd, bitmap, block_size, 1024 + (group_desc[0].bg_inode_bitmap - 1)*block_size);

  for(i = 1; i < (num_inodes/num_groups)+1; i = i + 1) {//Inode 0 is reserved, start at inode 1
    int index = (i-1)/8;
    int offset = (i-1) % 8;
    if((bitmap[index] & (1 << offset)) == 0)
      printf("IFREE,%d\n", i); 
  }

  struct ext2_inode inode;
  
  for(i = 1; (unsigned int) i < super.s_inodes_per_group; i = i + 1) { //I node summary start
    pread(fd, &inode, sizeof(struct ext2_inode), 1024 +
	  (group_desc[0].bg_inode_table-1)*block_size + (i-1)*sizeof(struct ext2_inode));

    if((inode.i_mode != 0) && (inode.i_links_count != 0)) {
      char file_type;

      if(S_ISREG(inode.i_mode))
	file_type = 'f';
      else if(S_ISDIR(inode.i_mode))
	file_type = 'd';
      else if(S_ISLNK(inode.i_mode))
	file_type = 's';
      else
	file_type = '?';

      int mode = 0xfff & inode.i_mode;
      char create_time[100], modify_time[100], access_time[100];
      
      gm_get((time_t) inode.i_ctime, create_time);
      gm_get((time_t) inode.i_mtime, modify_time);
      gm_get((time_t) inode.i_atime, access_time);
      
      char inode_print[500], optional_print[500] = "";
      snprintf(inode_print, 500, "INODE,%d,%c,%o,%d,%d,%d,%s,%s,%s,%d,%d", i, file_type,
	     mode, inode.i_uid, inode.i_gid, inode.i_links_count, create_time, modify_time,
	     access_time, inode.i_size, inode.i_blocks);


      if(file_type == 'f' || file_type == 'd' || (file_type == 's' && inode.i_size >=60))
	snprintf(optional_print, 500, ",%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",
		 inode.i_block[0], inode.i_block[1], inode.i_block[2], inode.i_block[3],
		 inode.i_block[4], inode.i_block[5], inode.i_block[6], inode.i_block[7],
		 inode.i_block[8], inode.i_block[9], inode.i_block[10], inode.i_block[11],
		 inode.i_block[12], inode.i_block[13], inode.i_block[14]);

      int toggle_ind[3] = {0, 0, 0};
      if(file_type == 'f' || file_type == 'd')
	for(iter = 12; iter < 15; iter = iter + 1) 
	  if(inode.i_block[iter] != 0)
	    toggle_ind[iter-12] = 1;

      printf("%s%s\n", inode_print, optional_print);

      if(file_type == 'd') {
	int total_size = 0;
	int full_size = inode.i_size;
	
	for(iter = 0; iter < 15; iter = iter + 1) {
	  if(inode.i_block[iter] != 0) {
	    int start_pt = 1024 + (inode.i_block[iter]-1)*block_size;
	    int offset = 0;
	    struct ext2_dir_entry dir;
	    pread(fd, &dir, 9, start_pt + offset);
	      
	    while(dir.inode != 0 && total_size < full_size) {
		pread(fd, &dir, 9, start_pt + offset);//read 9 into a dir struct
		pread(fd, &dir, 8 + dir.name_len, start_pt + offset);//read full dir struct
		char name[256];
		memcpy(name, dir.name, dir.name_len);
		name[dir.name_len] = 0;  //set null byte at end of name
		
		printf("DIRENT,%d,%d,%d,%d,%d,'%s'\n", i, offset, dir.inode, dir.rec_len,
		       dir.name_len, name);
		
		offset = offset + dir.rec_len;
		total_size = total_size + offset;
		pread(fd, &dir, 9, start_pt + offset);
	    }
	  }
	}//end of for

      }//end of nested if

      int blk_entry_sz = sizeof(inode.i_block[0]);
      int num_block_entries = block_size/blk_entry_sz;
      
      if(toggle_ind[0])
	indir(fd, inode.i_block[12], block_size, i, 12, 1);
      if(toggle_ind[1])
	indir(fd, inode.i_block[13], block_size, i, 12 + num_block_entries, 2);
      if(toggle_ind[2])
	indir(fd, inode.i_block[14], block_size, i, 12 + num_block_entries*num_block_entries +
	      num_block_entries, 3);
    }


  }
  
    close(fd);
    exit(0);
}
