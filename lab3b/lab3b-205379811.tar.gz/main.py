#!/usr/bin/env python3
import sys


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


if len(sys.argv) != 2:
    if len(sys.argv) < 2:
        print("Too few arguments passed\n")
    if len(sys.argv) > 2:
        print("Too many arguments passed\n")
    sys.exit(1)

if ".csv" not in sys.argv[1]:
    print("Incorrect file given, a .csv file is required\n")
    sys.exit(1)

f = open(sys.argv[1], "r")
f1 = f.readlines()

super_line = f1[0].split(",")
num_blocks = int(super_line[1])

# boot block, SB, and group block always used
reserved_block_bitmap = [0, 1, 2]
group_line = f1[1].split(",")
reserved_block_bitmap.append(int(group_line[6]))
reserved_block_bitmap.append(int(group_line[7]))
reserved_block_bitmap.append(int(group_line[8]))

free_block_bitmap = []
inode_blocks = []
for line in f1:
    if "BFREE" in line:
        bfree_line = line.split(",")
        free_block_bitmap.append(int(bfree_line[1]))

    if "INODE" in line:
        inode_line = line.split(",")
        if len(inode_line) > 12:
            for iterator in range(15):
                if int(inode_line[12 + iterator]) != 0:
                    inode_blocks.append(list())
                    inode_blocks[-1] = ("BLOCK", int(inode_line[iterator + 12]), int(inode_line[1]), iterator)
                    # word, block, inode, offset

    if "INDIRECT" in line:
        indirect_line = line.split(",")
        inode_blocks.append(list())
        indirect_string = ""

        if int(indirect_line[2]) == 1:
            indirect_string = "INDIRECT"
        elif int(indirect_line[2]) == 2:
            indirect_string = "DOUBLE INDIRECT"
        elif int(indirect_line[2]) == 3:
            indirect_string = "TRIPLE INDIRECT"

        inode_blocks[-1] = (indirect_string+" BLOCK", int(indirect_line[5]), int(indirect_line[1]), int(indirect_line[3]))

my_block_bitmap = []
for inode in inode_blocks:
    if inode[1] < 0 or inode[1] > num_blocks:
        print("INVALID " + inode[0] + " " + str(inode[1]) + " IN INODE " + str(inode[2]) + " AT OFFSET " + str(inode[3]))
    if inode[1] in reserved_block_bitmap:
        print("RESERVED " + inode[0] + " " + str(inode[1]) + " IN INODE " + str(inode[2]) + " AT OFFSET " + str(inode[3]))
    if inode[1] in free_block_bitmap:
        print("ALLOCATED " + inode[0] + " " + str(inode[1]) + " IN INODE " + str(inode[2]) + " AT OFFSET " + str(inode[3]))
    if inode[1] in my_block_bitmap:
        print("DUPLICATED " + inode[0] + " " + str(inode[1]) + " IN INODE " + str(inode[2]) + " AT OFFSET " + str(inode[3]))
    my_block_bitmap.append(inode[1])

# debugging print statements
# print(reserved_block_bitmap)
# print(free_block_bitmap)
# print(inode_blocks)

f.close()

